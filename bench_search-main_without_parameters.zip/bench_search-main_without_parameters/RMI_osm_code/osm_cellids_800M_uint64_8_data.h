namespace osm_cellids_800M_uint64_8 {
const double L0_PARAMETER0 = -86.8865853361271;
const double L0_PARAMETER1 = 0.00000000000000010585787298181993;
extern char* L1_PARAMETERS;
} // namespace
