namespace osm_cellids_800M_uint64_6 {
extern uint32_t* L0_PARAMETERS;
extern char* L1_PARAMETERS;
} // namespace
