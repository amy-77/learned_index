namespace osm_cellids_800M_uint64_9 {
const double L0_PARAMETER0 = -11.323047265276024;
const double L0_PARAMETER1 = 0.000000000000000013237177396532586;
extern char* L1_PARAMETERS;
} // namespace
