namespace osm_cellids_800M_uint64_7 {
const double L0_PARAMETER0 = -2764.9017997870815;
const double L0_PARAMETER1 = 0.0000000000000033874574283071137;
extern char* L1_PARAMETERS;
} // namespace
