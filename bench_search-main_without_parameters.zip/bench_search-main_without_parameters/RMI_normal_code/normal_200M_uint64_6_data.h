namespace normal_200M_uint64_6 {
const double L0_PARAMETER0 = -143.4008625879493;
const double L0_PARAMETER1 = 0.00000000000000004486447280140228;
extern char* L1_PARAMETERS;
} // namespace
