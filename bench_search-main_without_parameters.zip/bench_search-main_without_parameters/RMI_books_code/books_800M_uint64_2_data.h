namespace books_800M_uint64_2 {
const double L0_PARAMETER0 = 0.0;
const double L0_PARAMETER1 = 0.00000000000045474724246624647;
extern char* L1_PARAMETERS;
} // namespace
