namespace books_800M_uint64_4 {
const double L0_PARAMETER0 = 0.0;
const double L0_PARAMETER1 = 0.000000000000056843310440590716;
extern char* L1_PARAMETERS;
} // namespace
