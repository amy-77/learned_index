namespace books_800M_uint64_6 {
const double L0_PARAMETER0 = 0.0;
const double L0_PARAMETER1 = 0.000000000000014210746294984743;
extern char* L1_PARAMETERS;
} // namespace
