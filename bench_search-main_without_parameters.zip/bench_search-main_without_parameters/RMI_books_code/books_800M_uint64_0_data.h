namespace books_800M_uint64_0 {
const double L0_PARAMETER0 = 0.0;
const double L0_PARAMETER1 = 0.0000000000018189892951256376;
extern char* L1_PARAMETERS;
} // namespace
