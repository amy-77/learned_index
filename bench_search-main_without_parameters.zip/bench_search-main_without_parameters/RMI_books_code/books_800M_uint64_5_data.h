namespace books_800M_uint64_5 {
const double L0_PARAMETER0 = 0.0;
const double L0_PARAMETER1 = 0.000000000000028421601010186734;
extern char* L1_PARAMETERS;
} // namespace
