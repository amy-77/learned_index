namespace books_800M_uint64_8 {
const double L0_PARAMETER0 = 0.0;
const double L0_PARAMETER1 = 0.000000000000000110913882245267;
extern char* L1_PARAMETERS;
} // namespace
