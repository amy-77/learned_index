namespace books_800M_uint64_7 {
const double L0_PARAMETER0 = 0.0;
const double L0_PARAMETER1 = 0.0000000000000035526052585832492;
extern char* L1_PARAMETERS;
} // namespace
