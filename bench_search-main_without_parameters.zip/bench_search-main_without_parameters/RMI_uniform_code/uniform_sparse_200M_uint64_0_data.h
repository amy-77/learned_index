namespace uniform_sparse_200M_uint64_0 {
const double L0_PARAMETER0 = -0.0004710164160546532;
const double L0_PARAMETER1 = 0.0000000000009094946479035202;
char* L1_PARAMETERS;
} // namespace
