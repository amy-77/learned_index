namespace uniform_sparse_200M_uint64_7 {
const double L0_PARAMETER0 = -0.0000009199259176724397;
const double L0_PARAMETER1 = 0.0000000000000017763026299570367;
char* L1_PARAMETERS;
} // namespace
