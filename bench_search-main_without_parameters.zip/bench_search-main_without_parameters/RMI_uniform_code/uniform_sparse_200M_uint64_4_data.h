namespace uniform_sparse_200M_uint64_4 {
const double L0_PARAMETER0 = -0.000014719235804276571;
const double L0_PARAMETER1 = 0.000000000000028421655230942257;
char* L1_PARAMETERS;
} // namespace
