namespace lognormal_200M_uint64_6 {
const double L0_PARAMETER0 = 15766.693000959864;
const double L0_PARAMETER1 = 0.0000000000008979090082422239;
extern char* L1_PARAMETERS;
} // namespace
