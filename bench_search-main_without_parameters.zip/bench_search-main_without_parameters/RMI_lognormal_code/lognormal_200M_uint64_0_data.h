namespace lognormal_200M_uint64_0 {
const double L0_PARAMETER0 = 8072802.318618288;
const double L0_PARAMETER1 = 0.00000000045972940834984724;
extern char* L1_PARAMETERS;
} // namespace
