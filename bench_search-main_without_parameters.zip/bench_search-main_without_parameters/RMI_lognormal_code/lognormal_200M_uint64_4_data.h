namespace lognormal_200M_uint64_4 {
const double L0_PARAMETER0 = 126137.04404015152;
const double L0_PARAMETER1 = 0.000000000007183272005650718;
extern char* L1_PARAMETERS;
} // namespace
