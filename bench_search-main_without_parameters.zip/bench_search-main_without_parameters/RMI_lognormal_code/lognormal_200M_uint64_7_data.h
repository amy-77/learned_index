namespace lognormal_200M_uint64_7 {
const double L0_PARAMETER0 = 7883.096481534065;
const double L0_PARAMETER1 = 0.00000000000044895453263224694;
extern char* L1_PARAMETERS;
} // namespace
