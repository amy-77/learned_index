namespace lognormal_200M_uint64_1 {
const double L0_PARAMETER0 = 4036400.909264595;
const double L0_PARAMETER1 = 0.0000000002298647041750253;
extern char* L1_PARAMETERS;
} // namespace
