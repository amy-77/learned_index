namespace lognormal_200M_uint64_8 {
const double L0_PARAMETER0 = 492.2251833788096;
const double L0_PARAMETER1 = 0.000000000000028059072961911658;
extern char* L1_PARAMETERS;
} // namespace
