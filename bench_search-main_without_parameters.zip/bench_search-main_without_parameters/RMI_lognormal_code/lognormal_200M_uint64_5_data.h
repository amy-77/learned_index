namespace lognormal_200M_uint64_5 {
const double L0_PARAMETER0 = 63068.27202368867;
const double L0_PARAMETER1 = 0.0000000000035916359984946645;
extern char* L1_PARAMETERS;
} // namespace
