namespace lognormal_200M_uint64_9 {
const double L0_PARAMETER0 = 61.09334217658146;
const double L0_PARAMETER1 = 0.0000000000000035034622260880387;
extern char* L1_PARAMETERS;
} // namespace
