namespace lognormal_200M_uint64_2 {
const double L0_PARAMETER0 = 2018200.2046253476;
const double L0_PARAMETER1 = 0.0000000001149323520880022;
extern char* L1_PARAMETERS;
} // namespace
