namespace fb_200M_uint64_2 {
const double L0_PARAMETER0 = 647.8975797672756;
const double L0_PARAMETER1 = 0.00005416066012805152;
extern char* L1_PARAMETERS;
} // namespace
