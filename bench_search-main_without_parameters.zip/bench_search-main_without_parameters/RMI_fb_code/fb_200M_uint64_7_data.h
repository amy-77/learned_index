namespace fb_200M_uint64_7 {
const double L0_PARAMETER0 = 4.56560426804208;
const double L0_PARAMETER1 = 0.00000042313015733017296;
extern char* L1_PARAMETERS;
} // namespace
