namespace fb_200M_uint64_1 {
const double L0_PARAMETER0 = 1296.2951730568893;
const double L0_PARAMETER1 = 0.0001083213202560954;
extern char* L1_PARAMETERS;
} // namespace
