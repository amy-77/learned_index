namespace fb_200M_uint64_3 {
const double L0_PARAMETER0 = 161.59939581138315;
const double L0_PARAMETER1 = 0.000013540165032011197;
extern char* L1_PARAMETERS;
} // namespace
