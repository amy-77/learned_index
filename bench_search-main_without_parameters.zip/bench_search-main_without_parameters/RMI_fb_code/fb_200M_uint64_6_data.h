namespace fb_200M_uint64_6 {
const double L0_PARAMETER0 = 19.762427154462785;
const double L0_PARAMETER1 = 0.000001692520628961222;
extern char* L1_PARAMETERS;
} // namespace
