namespace fb_200M_uint64_4 {
const double L0_PARAMETER0 = 80.54969800752588;
const double L0_PARAMETER1 = 0.000006770082516019887;
extern char* L1_PARAMETERS;
} // namespace
