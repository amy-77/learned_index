namespace fb_200M_uint64_8 {
const double L0_PARAMETER0 = -0.34147978904258025;
const double L0_PARAMETER1 = 0.000000013222811763153564;
extern char* L1_PARAMETERS;
} // namespace
