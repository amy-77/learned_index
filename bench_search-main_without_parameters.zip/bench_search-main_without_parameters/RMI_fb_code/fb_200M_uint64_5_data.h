namespace fb_200M_uint64_5 {
const double L0_PARAMETER0 = 40.02484979799192;
const double L0_PARAMETER1 = 0.0000033850412580060154;
extern char* L1_PARAMETERS;
} // namespace
