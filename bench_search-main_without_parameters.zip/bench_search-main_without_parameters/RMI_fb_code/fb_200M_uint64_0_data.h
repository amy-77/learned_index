namespace fb_200M_uint64_0 {
const double L0_PARAMETER0 = 2593.0904023256153;
const double L0_PARAMETER1 = 0.0002166426405130368; 
extern char* L1_PARAMETERS;
} // namespace
