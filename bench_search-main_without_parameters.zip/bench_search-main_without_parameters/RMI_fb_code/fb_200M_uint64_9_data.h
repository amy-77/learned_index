namespace fb_200M_uint64_9 {
const double L0_PARAMETER0 = -0.47661188668726595;
const double L0_PARAMETER1 = 0.0000000016527591681054777;
extern char* L1_PARAMETERS;
} // namespace
