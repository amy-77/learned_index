namespace uniform_sparse_200M_uint64_2 {
const double L0_PARAMETER0 = -0.00011775408295758741;
const double L0_PARAMETER1 = 0.00000000000022737362131829855;
extern char* L1_PARAMETERS;
} // namespace
