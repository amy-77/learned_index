namespace uniform_sparse_200M_uint64_8 {
const double L0_PARAMETER0 = -0.000000028720487495922906;
const double L0_PARAMETER1 = 0.00000000000000005545694114340796;
extern char* L1_PARAMETERS;
} // namespace
