namespace uniform_sparse_200M_uint64_6 {
const double L0_PARAMETER0 = -0.000003679787894993266;
const double L0_PARAMETER1 = 0.00000000000000710537315015408;
extern char* L1_PARAMETERS;
} // namespace
