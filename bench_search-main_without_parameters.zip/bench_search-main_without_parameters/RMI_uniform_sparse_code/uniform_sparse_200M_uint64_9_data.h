namespace uniform_sparse_200M_uint64_9 {
const uint64_t L0_PARAMETER0 = 0UL;
const uint64_t L0_PARAMETER1 = 7UL;
extern char* L1_PARAMETERS;
} // namespace
