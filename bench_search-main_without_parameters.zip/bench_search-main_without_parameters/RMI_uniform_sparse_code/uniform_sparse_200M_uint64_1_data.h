namespace uniform_sparse_200M_uint64_1 {
const uint64_t L0_PARAMETER0 = 0UL;
const uint64_t L0_PARAMETER1 = 23UL;
extern char* L1_PARAMETERS;
} // namespace
