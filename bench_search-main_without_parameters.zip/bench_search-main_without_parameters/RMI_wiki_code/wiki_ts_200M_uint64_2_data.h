namespace wiki_ts_200M_uint64_2 {
const double L0_PARAMETER0 = -17369365.561982863;
const double L0_PARAMETER1 = 0.017729774412781375;
extern char* L1_PARAMETERS;
} // namespace
