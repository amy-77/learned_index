namespace wiki_ts_200M_uint64_7 {
const double L0_PARAMETER0 = -302042.00491972367;
const double L0_PARAMETER1 = 0.00027242848301432354;
extern char* L1_PARAMETERS;
} // namespace
