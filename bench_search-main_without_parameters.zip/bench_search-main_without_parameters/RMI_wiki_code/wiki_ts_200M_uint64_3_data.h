namespace wiki_ts_200M_uint64_3 {
const double L0_PARAMETER0 = -4342338.284610383;
const double L0_PARAMETER1 = 0.004432440432863871;
extern char* L1_PARAMETERS;
} // namespace
