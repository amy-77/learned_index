namespace wiki_ts_200M_uint64_4 {
const double L0_PARAMETER0 = -2171167.0717149694;
const double L0_PARAMETER1 = 0.00221621810287762;
extern char* L1_PARAMETERS;
} // namespace
