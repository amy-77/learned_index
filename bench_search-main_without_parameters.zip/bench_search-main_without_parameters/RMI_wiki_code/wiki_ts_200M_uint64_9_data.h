namespace wiki_ts_200M_uint64_9 {
const double L0_PARAMETER0 = -525.9299164537764;
const double L0_PARAMETER1 = 0.0000005368427961506917;
extern char* L1_PARAMETERS;
} // namespace
