namespace wiki_ts_200M_uint64_5 {
const double L0_PARAMETER0 = -1085581.4652672624;
const double L0_PARAMETER1 = 0.0011081069378844944;
extern char* L1_PARAMETERS;
} // namespace
