namespace wiki_ts_200M_uint64_6 {
const double L0_PARAMETER0 = -542788.6620434088;
const double L0_PARAMETER1 = 0.0005540513553879316;
extern char* L1_PARAMETERS;
} // namespace
