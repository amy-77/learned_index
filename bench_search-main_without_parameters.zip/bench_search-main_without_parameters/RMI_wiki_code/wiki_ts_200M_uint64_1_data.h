namespace wiki_ts_200M_uint64_1 {
const double L0_PARAMETER0 = -34738735.26514617;
const double L0_PARAMETER1 = 0.035459553052671386;
extern char* L1_PARAMETERS;
} // namespace
