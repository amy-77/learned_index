namespace wiki_ts_200M_uint64_8 {
const double L0_PARAMETER0 = -4236.427594741837;
const double L0_PARAMETER1 = 0.000004324332129623289;
extern char* L1_PARAMETERS;
} // namespace
