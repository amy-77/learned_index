namespace wiki_ts_200M_uint64_0 {
const double L0_PARAMETER0 = -69477474.67147279;
const double L0_PARAMETER1 = 0.0709191103324514;
extern char* L1_PARAMETERS;
} // namespace
